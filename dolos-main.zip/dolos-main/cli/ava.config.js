export default {
  files: [
    "src/test/**.ts"
  ],
  extensions: [
    "ts"
  ],
  require: [
    "ts-node/register"
  ]
};
