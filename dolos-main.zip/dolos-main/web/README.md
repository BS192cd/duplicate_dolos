# Dolos-web

Dolos visualisation in your browser using. Please see the [@dodona/dolos](https://www.npmjs.com/package/@dodona/dolos) package for more information.

### Development

Please refer to [CONTRIBUTING.md](./CONTRIBUTING.md) for instructions on how to develop with the Dolos UI.

