export type UploadReportStatus =
  | "queued"
  | "running"
  | "failed"
  | "error"
  | "finished"
  | "purged"
  | "api_error";
