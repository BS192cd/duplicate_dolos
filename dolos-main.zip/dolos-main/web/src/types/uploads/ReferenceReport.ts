export type ReferenceReport = {
  referenceId: string;
  publicId: string;
};
