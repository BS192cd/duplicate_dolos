<template>
  <v-app>
    <router-view />
    <snackbar />
  </v-app>
</template>
