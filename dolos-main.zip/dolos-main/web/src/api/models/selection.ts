export interface Selection {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}
