import { Label } from "@/api/models";

export interface Legend {
  [key: string]: Label;
}
