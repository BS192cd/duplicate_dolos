export type Hash = number;
