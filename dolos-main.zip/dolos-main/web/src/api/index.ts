// Constants
export const DATA_PATH = "data";
export const DATA_URL = `${window.location.protocol}//${window.location.host}${window.location.pathname}${DATA_PATH}`;
