export function webroot(): string;
