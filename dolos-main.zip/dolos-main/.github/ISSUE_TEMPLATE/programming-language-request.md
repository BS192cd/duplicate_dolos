---
name: Programming language request
about: Request support for a new programming language here
title: 'Programmign language request:'
labels: ''
assignees: ''

---

**What programming language do you want Dolos to support?**


**(Optionally) Is there a tree-sitter parser for this language?**
See if you can find a parser matching your language on this page: https://tree-sitter.github.io/tree-sitter/#parsers
